wifi_secrets=[
    {'ssid':'Tuan', 'password':'0973907059'},
    {'ssid':'nah', 'password':'abc12345'},
]

aio_secrets={
    'aio_username':'tuan_nguyen_brtchip',
    'aio_key':'aio_jJYQ56mFz4DLKLs4IY0hNMWIuSeI'
}